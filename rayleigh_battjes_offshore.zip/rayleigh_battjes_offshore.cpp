/***********************************************************************
 * Program: rayleigh_battjes_offshore.cpp
 * Author: Gemini
 *
 * Description:
 * This program calculates and compares an extensive set of theoretical
 * wave height ratios for two different deep-water wave models, for N
 * ranging from 1 to 10,000.
 *
 * It computes ratios related to average wave heights, extreme waves,
 * and overall distribution shape for offshore (deep-water) conditions.
 *
 * 1. Theoretical Rayleigh Model:
 * - Assumes a narrow-band energy spectrum.
 * - Ratios are normalized by the statistical significant wave height, H(1/3),
 * which is the mean of the highest 1/3 of waves.
 *
 * 2. Battjes & Groenendijk (2000) Deep-Water Model:
 * - Uses an empirical adjustment to better fit broad-banded sea states.
 * - Ratios are normalized by the spectral significant wave height, Hm0,
 * where Hm0 = 4 * sqrt(m0). For a pure Rayleigh distribution,
 * this relates to Hrms via Hm0 = Hrms * sqrt(2).
 *
 * The results are written to a fixed-width, tab-separated file named
 * "output.txt", formatted for A3 landscape viewing.
 *
 * Compilation (using g++):
 * g++ -O3 -march=native -std=c++17 -Wall -Wextra -pedantic \
 * -Wconversion -Wsign-conversion -static -static-libgcc -static-libstdc++ \
 * -o rayleigh_battjes_offshore rayleigh_battjes_offshore.cpp
 *
 * Usage:
 * ./rayleigh_battjes_offshore
 ***********************************************************************/

#include <iostream>
#include <fstream>
#include <cmath>
#include <iomanip>
#include <vector>

// Use double for high-precision floating-point calculations.
using Real = double;

// Define the mathematical constant PI with high precision.
const Real PI = acos(-1.0);

// --- FORWARD DECLARATIONS ---

Real get_H1N_over_Hrms(int N);
Real get_HN_over_Hrms(int N);
Real get_Hmax_over_Hrms(int N);

// Structure to hold pre-computed constant ratios to avoid recalculation.
struct PrecomputedRatios {
    Real H1_3_over_Hrms;
    Real Hm0_over_Hrms;
};


/**
 * @brief Helper function to perform all calculations and write a formatted row.
 * @param N The current N value.
 * @param outFile The output file stream.
 * @param ratios A struct containing all pre-computed constant ratios.
 */
void calculateAndWrite(int N, std::ofstream& outFile, const PrecomputedRatios& ratios) {
    // --- N-dependent calculations ---
    // Base ratio for the current N.
    Real H1_N_over_Hrms = get_H1N_over_Hrms(N);
    // Theoretical maximum wave height for a sea state of N waves.
    Real Hmax_over_Hrms = get_Hmax_over_Hrms(N);

    // --- Final Ratio Calculations ---
    Real ratio_vs_H1_3 = H1_N_over_Hrms / ratios.H1_3_over_Hrms;
    Real ratio_vs_Hm0 = H1_N_over_Hrms / ratios.Hm0_over_Hrms;
    Real Hmax_div_H1_3 = Hmax_over_Hrms / ratios.H1_3_over_Hrms;

    // --- Write Row to File ---
    outFile << std::left
            << std::setw(8) << N
            << std::setw(25) << H1_N_over_Hrms
            << std::setw(25) << ratio_vs_H1_3
            << std::setw(25) << ratio_vs_Hm0
            << std::setw(25) << Hmax_div_H1_3 << "\n";
}


int main() {
    // Attempt to open the output file for writing.
    std::ofstream outFile("output.txt");
    if (!outFile.is_open()) {
        std::cerr << "Error: Could not open output.txt for writing." << std::endl;
        return 1;
    }

    // Set output stream formatting for the entire file.
    outFile << std::fixed << std::setprecision(15);

    // --- Pre-compute all constant ratios ---
    PrecomputedRatios ratios;
    ratios.H1_3_over_Hrms = get_H1N_over_Hrms(3);
    ratios.Hm0_over_Hrms = sqrt(2.0);

    // Derived constant ratios for the header
    Real H_mean_over_Hrms = get_H1N_over_Hrms(1);
    Real H_median_over_Hrms = get_HN_over_Hrms(2);
    Real H1_10_over_Hrms = get_H1N_over_Hrms(10);
    Real H1_100_over_Hrms = get_H1N_over_Hrms(100);
    Real H1_1000_over_Hrms = get_H1N_over_Hrms(1000);
    Real H1_percent_over_Hrms = get_HN_over_Hrms(100);
    Real H10_percent_over_Hrms = get_HN_over_Hrms(10);
    Real Hmax1000_over_Hrms = get_Hmax_over_Hrms(1000);

    // --- Calculate Diagnostic Ratios for Header ---
    Real Hm0_over_H1_3_ratio = ratios.Hm0_over_Hrms / ratios.H1_3_over_Hrms;
    Real Hrms_div_Hmean_ratio = 1.0 / H_mean_over_Hrms;
    Real H1_3_div_Hmedian_ratio = ratios.H1_3_over_Hrms / H_median_over_Hrms;
    Real H1_10_div_Hmedian_ratio = H1_10_over_Hrms / H_median_over_Hrms;
    Real H100_div_H10_ratio = H1_100_over_Hrms / H1_10_over_Hrms;
    Real H1000_div_H100_ratio = H1_1000_over_Hrms / H1_100_over_Hrms;
    Real H1_percent_over_H1_3_ratio = H1_percent_over_Hrms / ratios.H1_3_over_Hrms;
    Real H10_percent_over_H1_3_ratio = H10_percent_over_Hrms / ratios.H1_3_over_Hrms;
    Real Hmax1000_over_H1_3_ratio = Hmax1000_over_Hrms / ratios.H1_3_over_Hrms;
    Real Hmax1000_over_Hmean_ratio = Hmax1000_over_Hrms / H_mean_over_Hrms;


    // --- Write Introductory Note ---
    outFile << "# Wave Height Ratio Comparison: Theoretical Rayleigh vs. Battjes & Groenendijk (2000) Convention\n\n"
            << "# This file calculates and compares wave height statistics for two fundamental deep-water models.\n"
            << "# Both models are based on the Rayleigh probability distribution, but they differ in how they relate wave statistics to the total energy of the sea state.\n\n"
            << "# --- Model Descriptions ---\n\n"
            << "# 1. Theoretical Rayleigh Model:\n"
            << "#    - Context: This is the pure, classical model for wave heights, first derived for sea waves by Longuet-Higgins (1952).\n"
            << "#    - Assumption: It assumes the sea surface is a linear Gaussian process with a narrow energy spectrum (like a clean, long-distance swell).\n"
            << "#    - Key Relationship: It uses the theoretical link between the root-mean-square wave height (Hrms) and the total wave energy (m0): Hrms = sqrt(8 * m0) approx 2.828 * sqrt(m0).\n"
            << "#    - Normalization: In this file, its ratios are normalized by H(1/3), the statistical significant wave height, which is the literal mean of the highest one-third of waves.\n\n"
            << "# 2. Battjes & Groenendijk (B&G) Deep-Water Convention:\n"
            << "#    - Context: This is not a different distribution shape, but rather an empirical adjustment to the Rayleigh model's parameters to better fit real, wind-driven seas.\n"
            << "#      It represents the DEEP-WATER LIMIT of the full B&G shallow-water model.\n"
            << "#    - Assumption: It acknowledges that real ocean waves have a broad energy spectrum, not a narrow one.\n"
            << "#    - Key Relationship: The full B&G model defines Hrms as a function of depth: Hrms = (2.69 + 3.24*sqrt(m0)/d) * sqrt(m0).\n"
            << "#      In deep water (as d -> infinity), the depth-dependent term vanishes, and the formula simplifies to its deep-water limit: Hrms approx. 2.69 * sqrt(m0).\n"
            << "#      This program uses this deep-water value, based on field data analysis by Goda (1979).\n"
            << "#    - Normalization: Its ratios are normalized by the spectral significant wave height, Hm0, defined as Hm0 = 4 * sqrt(m0).\n\n"
            << "# --- Key Difference ---\n"
            << "# The core difference lies in the Hrms/sqrt(m0) ratio (approx. 2.828 for pure Rayleigh vs. 2.69 for the B&G deep-water convention).\n"
            << "# This small change in the definition of Hrms leads to slightly different, but important, variations in the final statistical ratios.\n"
            << "# The Theoretical Rayleigh model is the pure mathematical ideal. The B&G convention is an engineering adjustment for more realistic, broad-banded seas.\n\n"
            << "# --- Constant Ratios for a Rayleigh Distribution ---\n"
            << "# These diagnostic ratios are constant for a pure Rayleigh distribution and describe its fundamental shape.\n"
            << "# Note: H(1%) is the wave height exceeded by 1% of waves, equivalent to H_N where N=100.\n"
            << "# Hm0/H(1/3)          : " << std::left << std::setw(20) << Hm0_over_H1_3_ratio << " (Ratio of spectral to statistical significant wave height)\n"
            << "# Hrms/H_mean         : " << std::left << std::setw(20) << Hrms_div_Hmean_ratio << " (Coefficient of variation, indicates spread)\n"
            << "# H(1/3)/H_median     : " << std::left << std::setw(20) << H1_3_div_Hmedian_ratio << " (Indicator of the upper tail weight vs. the center)\n"
            << "# H(1/10)/H_median    : " << std::left << std::setw(20) << H1_10_div_Hmedian_ratio << " (More sensitive indicator of the upper tail weight)\n"
            << "# H(1/100)/H(1/10)    : " << std::left << std::setw(20) << H100_div_H10_ratio << " (Growth ratio of extreme wave averages)\n"
            << "# H(1/1000)/H(1/100)  : " << std::left << std::setw(20) << H1000_div_H100_ratio << " (Growth ratio for more extreme wave averages)\n"
            << "# H(1%)/H(1/3)        : " << std::left << std::setw(20) << H1_percent_over_H1_3_ratio << " (Ratio of the 1% exceedance wave to significant wave)\n"
            << "# H(10%)/H(1/3)       : " << std::left << std::setw(20) << H10_percent_over_H1_3_ratio << " (Ratio of the 10% exceedance wave to significant wave)\n"
            << "# H_max(N=1000)/H(1/3): " << std::left << std::setw(20) << Hmax1000_over_H1_3_ratio << " (Expected max wave in 1000 waves vs. significant wave)\n"
            << "# H_max(N=1000)/H_mean: " << std::left << std::setw(20) << Hmax1000_over_Hmean_ratio << " (Ratio of expected max to mean, indicates extreme range)\n\n"
            << "# --- Column Explanations ---\n"
            << "# N                       : Number of waves in the sea state.\n"
            << "# H(1/N)/Hrms             : The mean of the highest 1/N waves, normalized by the root-mean-square wave height. This is the base for other ratios.\n"
            << "# Rayleigh_H(1/N)/H(1/3)  : Ratio normalized by the statistical significant wave height (the literal mean of the highest 1/3 waves).\n"
            << "# BG_H(1/N)/Hm0           : Ratio normalized by the spectral significant wave height (Hm0 = 4*sqrt(m0)). The B&G deep-water convention.\n"
            << "# H_max/H(1/3)            : The ratio of the expected maximum wave height in N waves to the significant wave height. (H_max is approximated as Hrms*sqrt(2*ln(N))).\n"
            << "------------------------------------------------------------------------------------------------------------------------------------------------\n";

    // --- Write Header ---
    outFile << std::left
            << std::setw(8) << "N"
            << std::setw(25) << "H(1/N)/Hrms"
            << std::setw(25) << "Rayleigh_H(1/N)/H(1/3)"
            << std::setw(25) << "BG_H(1/N)/Hm0"
            << std::setw(25) << "H_max/H(1/3)" << "\n";


    // --- Main Calculation Loop with Custom Steps ---
    for (int N = 1; N < 50; ++N) {
        calculateAndWrite(N, outFile, ratios);
    }
    for (int N = 50; N < 100; N += 10) {
        calculateAndWrite(N, outFile, ratios);
    }
    for (int N = 100; N < 1000; N += 50) {
        calculateAndWrite(N, outFile, ratios);
    }
    for (int N = 1000; N <= 10000; N += 1000) {
        calculateAndWrite(N, outFile, ratios);
    }

    // Close the file stream.
    outFile.close();

    // Print a success message to the console.
    std::cout << "Successfully calculated and compared wave height ratios for N=1 to 10000." << std::endl;
    std::cout << "Results have been written to output.txt" << std::endl;

    return 0; // Indicate successful execution.
}


// --- FUNCTION DEFINITIONS ---

/**
 * @brief Calculates the ratio H(1/N)/Hrms for a pure Rayleigh distribution.
 * H(1/N) is the mean of the highest 1/N waves.
 * The formula is: H(1/N)/Hrms = sqrt(ln(N)) + N * sqrt(PI)/2 * erfc(sqrt(ln(N)))
 */
Real get_H1N_over_Hrms(int N) {
    if (N <= 0) return 0.0;
    if (N == 1) return sqrt(PI) / 2.0;
    Real n_real = static_cast<Real>(N);
    Real log_N = log(n_real);
    Real sqrt_log_N = sqrt(log_N);
    Real term1 = sqrt_log_N;
    Real term2 = n_real * (sqrt(PI) / 2.0) * erfc(sqrt_log_N);
    return term1 + term2;
}

/**
 * @brief Calculates the ratio H_N/Hrms for a pure Rayleigh distribution.
 * H_N is the wave height with an exceedance probability of 1/N.
 * The formula is: H_N/Hrms = sqrt(ln(N))
 */
Real get_HN_over_Hrms(int N) {
    if (N < 1) return 0.0; // Probability must be <= 1.
    if (N == 1) return 0.0; // H exceeded by all waves is 0.
    return sqrt(log(static_cast<Real>(N)));
}

/**
 * @brief Calculates the approximate ratio H_max/Hrms for a given N.
 * H_max is the expected maximum wave height in a sequence of N waves.
 * The formula is: H_max/Hrms = sqrt(2 * ln(N))
 */
Real get_Hmax_over_Hrms(int N) {
    if (N <= 1) return get_H1N_over_Hrms(1); // For N=1, H_max is just the mean.
    return sqrt(2.0 * log(static_cast<Real>(N)));
}
